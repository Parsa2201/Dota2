package com.ap.dota2.MainGame.map;

import com.ap.dota2.MainGame.standards.DotaDrawable;
import com.ap.dota2.MainGame.standards.Position;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.utils.Disposable;

public class Obstacle implements DotaDrawable, Disposable
{
    private Position position;

    @Override
    public void draw(Batch batch)
    {

    }

    @Override
    public void dispose()
    {

    }
}
