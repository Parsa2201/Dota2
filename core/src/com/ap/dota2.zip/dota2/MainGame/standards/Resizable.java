package com.ap.dota2.MainGame.standards;

public interface Resizable
{
    void resize(int width, int height);
}
