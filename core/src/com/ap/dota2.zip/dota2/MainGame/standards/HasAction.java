package com.ap.dota2.MainGame.standards;

public interface HasAction
{
    void action(float delta);
}
