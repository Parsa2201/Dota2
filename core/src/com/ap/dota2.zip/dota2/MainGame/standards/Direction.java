package com.ap.dota2.MainGame.standards;

public enum Direction
{
    UP, DOWN, LEFT, RIGHT, NONE
}
