package com.ap.dota2.MainGame.standards;

public class Damage
{
    private int damage;

    public Damage(int damage)
    {
        this.damage = damage;
    }

    public int getDamage()
    {
        return damage;
    }

    public void setDamage(int damage)
    {
        this.damage = damage;
    }
}
