package com.ap.dota2.MainGame.standards;

import com.badlogic.gdx.graphics.g2d.Batch;

public interface DotaDrawable
{
    void draw(Batch batch);
}
