package com.ap.dota2.MainGame.standards;

public class HP
{
    float hp;

    public HP(float hp)
    {
        this.hp = hp;
    }
}
